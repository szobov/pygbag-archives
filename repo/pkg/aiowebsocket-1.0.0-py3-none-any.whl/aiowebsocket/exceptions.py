

class FrameError(Exception):
    """ Frame Error """


class HandShakeError(Exception):
    """ HandShake Error """
